package lt.techin.demo.controller;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import lt.techin.demo.dto.movie.*;
import lt.techin.demo.model.Movie;
import lt.techin.demo.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

@RestController
@RequestMapping("/api/movies")
public class MovieController {

    private static final Logger LOGGER = Logger.getLogger(MovieController.class.getName());
    private final MovieService movieService;

    @Autowired
    public MovieController(MovieService movieService) {
        this.movieService = movieService;
    }

    @GetMapping
    public ResponseEntity<List<GetPartialMovieResponseDTO>> getMovies() {
        try {
            // Fetch all movies from the database
            List<Movie> movies = movieService.findAllMovies();

            // Map the movies to the response DTO
            List<GetPartialMovieResponseDTO> response = movies.stream()
                    .map(MovieMapper::toGetPartialMovieResponseDTO)
                    .toList();

            // Return the response
            return ResponseEntity.ok(response);
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error retrieving movies", ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

//    @GetMapping
//    public ResponseEntity<List<GetPartialMovieResponseDTO>> getMovies(
//            @RequestParam(defaultValue = "10") @Min(value = 1) int size,
//            @RequestParam(defaultValue = "1") @Min(value = 1) int page
//    ) {
//        try {
//            Pageable pageable = PageRequest.of(page - 1, size);
//            Page<Movie> moviePage = movieService.findAllMoviesPage(pageable);
//            List<GetPartialMovieResponseDTO> response = moviePage.getContent().stream()
//                    .map(MovieMapper::toGetPartialMovieResponseDTO)
//                    .toList();
//            return ResponseEntity.ok(response);
//        } catch (IllegalArgumentException ex) {
//            LOGGER.log(Level.WARNING, "Invalid pagination parameters: {0}", ex.getMessage());
//            return ResponseEntity.badRequest().body(null);
//        } catch (Exception ex) {
//            LOGGER.log(Level.SEVERE, "Error retrieving movies", ex);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
//        }
//    }

    @GetMapping("/{id}")
    public ResponseEntity<GetMovieResponseDTO> getMovie(@PathVariable long id) {
        try {
            Movie movie = movieService.findMovieById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Movie not found"));
            return ResponseEntity.ok(MovieMapper.toGetMovieResponseDTO(movie));
        } catch (IllegalArgumentException ex) {
            LOGGER.log(Level.WARNING, "Movie not found: {0}", id);
            return ResponseEntity.notFound().build();
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error retrieving movie", ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @PostMapping
    public ResponseEntity<CreateMovieResponseDTO> addMovie(
            @Valid @RequestBody CreateMovieRequestDTO createMovieRequestDTO
    ) {
        try {
            if (createMovieRequestDTO.getCategoryIds() == null || createMovieRequestDTO.getCategoryIds().isEmpty()) {
                return ResponseEntity.badRequest().body(null);
            }

            Movie movie = MovieMapper.toMovie(createMovieRequestDTO);
            Set<Long> categoryIds = createMovieRequestDTO.getCategoryIds();
            Movie savedMovie = movieService.saveMovie(movie, categoryIds);

            return ResponseEntity.created(
                            ServletUriComponentsBuilder.fromCurrentRequest()
                                    .path("/{id}")
                                    .buildAndExpand(savedMovie.getId())
                                    .toUri())
                    .body(MovieMapper.toCreateMovieResponseDTO(savedMovie));
        } catch (DataAccessException ex) {
            LOGGER.log(Level.SEVERE, "Database error when saving movie", ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error saving movie", ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<UpdateMovieResponseDTO> updateMovie(
            @PathVariable long id,
            @Valid @RequestBody UpdateMovieRequestDTO updateMovieRequestDTO
    ) {
        try {
            if (!movieService.existsMovieById(id)) {
                return ResponseEntity.notFound().build();
            }

            Movie movieFromDb = movieService.findMovieById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Movie not found"));

            Movie updatedMovie = MovieMapper.toMovie(updateMovieRequestDTO);
            updatedMovie.setId(movieFromDb.getId());

            Set<Long> categoryIds = updateMovieRequestDTO.getCategoryIds();
            Movie savedMovie = movieService.saveMovie(updatedMovie, categoryIds);

            return ResponseEntity.ok(MovieMapper.toUpdateMovieResponseDTO(savedMovie));
        } catch (IllegalArgumentException ex) {
            LOGGER.log(Level.WARNING, "Invalid update request: {0}", ex.getMessage());
            return ResponseEntity.badRequest().body(null);
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error updating movie", ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMovie(@PathVariable long id) {
        try {
            if (!movieService.existsMovieById(id)) {
                return ResponseEntity.notFound().build();
            }

            movieService.deleteMovieById(id);
            return ResponseEntity.noContent().build();
        } catch (DataAccessException ex) {
            LOGGER.log(Level.SEVERE, "Database error when deleting movie", ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        } catch (Exception ex) {
            LOGGER.log(Level.SEVERE, "Error deleting movie", ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
