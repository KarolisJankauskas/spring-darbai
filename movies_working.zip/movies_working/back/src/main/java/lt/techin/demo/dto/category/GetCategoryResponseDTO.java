package lt.techin.demo.dto.category;

public record GetCategoryResponseDTO(long id, String name) {
}
