package lt.techin.demo.dto.movie;

import lt.techin.demo.model.Category;

import java.time.LocalDate;
import java.util.List;

public record CreateMovieResponseDTO(
        long id,
        String title,
        String director,
        String description,
        String imageUrl,
        int duration,
        LocalDate releaseDate,
        List<Category> categories
) { }