package lt.techin.demo.dto.movie;

import lt.techin.demo.model.Category;

import java.time.LocalDate;
import java.util.List;

public record GetPartialMovieResponseDTO(
        long id,
        String title,
        String director,
        String imageUrl,
        LocalDate releaseDate,
        List<Category> categories
) { }