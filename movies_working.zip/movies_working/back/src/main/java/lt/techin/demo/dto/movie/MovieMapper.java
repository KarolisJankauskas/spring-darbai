package lt.techin.demo.dto.movie;

import lt.techin.demo.model.Category;
import lt.techin.demo.model.Movie;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

public class MovieMapper {

    public static GetPartialMovieResponseDTO toGetPartialMovieResponseDTO(Movie movie) {
        return new GetPartialMovieResponseDTO(
                movie.getId(),
                movie.getTitle(),
                movie.getDirector(),
                movie.getImageUrl(),
                movie.getReleaseDate(),
                movie.getCategories().stream().toList()
        );
    }

    public static CreateMovieResponseDTO toCreateMovieResponseDTO(Movie movie) {
        return new CreateMovieResponseDTO(
                movie.getId(),
                movie.getTitle(),
                movie.getDirector(),
                movie.getDescription(),
                movie.getImageUrl(),
                movie.getDuration(),
                movie.getReleaseDate(),
                movie.getCategories().stream().toList()
        );
    }

    public static GetMovieResponseDTO toGetMovieResponseDTO(Movie movie) {
        return new GetMovieResponseDTO(
                movie.getId(),
                movie.getTitle(),
                movie.getDirector(),
                movie.getDescription(),
                movie.getImageUrl(),
                movie.getDuration(),
                movie.getReleaseDate(),
                movie.getCategories().stream().toList(),
                movie.getReviews()
        );
    }

    public static UpdateMovieResponseDTO toUpdateMovieResponseDTO(Movie movie) {
        return new UpdateMovieResponseDTO(
                movie.getId(),
                movie.getTitle(),
                movie.getDirector(),
                movie.getDescription(),
                movie.getImageUrl(),
                movie.getDuration(),
                movie.getReleaseDate(),
                movie.getReviews(),
                movie.getCategories().stream().toList()
        );
    }

    public static Movie toMovie(CreateMovieRequestDTO createMovieRequestDTO) {
        Movie movie = new Movie();
        movie.setTitle(createMovieRequestDTO.title());
        movie.setDirector(createMovieRequestDTO.director());
        movie.setDescription(createMovieRequestDTO.description());
        movie.setImageUrl(createMovieRequestDTO.imageUrl());
        movie.setDuration(createMovieRequestDTO.duration());
        movie.setReleaseDate(createMovieRequestDTO.releaseDate());

        // Convert category IDs into a set of Category objects (Assuming this is done in Service Layer)
        Set<Category> categories = new HashSet<>();
        movie.setCategories(categories);

        return movie;
    }

    public static Movie toMovie(UpdateMovieRequestDTO updateMovieRequestDTO) {
        Movie movie = new Movie();
        movie.setId(updateMovieRequestDTO.id());
        movie.setTitle(updateMovieRequestDTO.title());
        movie.setDirector(updateMovieRequestDTO.director());
        movie.setDescription(updateMovieRequestDTO.description());
        movie.setImageUrl(updateMovieRequestDTO.imageUrl());
        movie.setDuration(updateMovieRequestDTO.duration());
        movie.setReleaseDate(updateMovieRequestDTO.releaseDate());
        movie.setReviews(updateMovieRequestDTO.reviews());

        // Convert category IDs into a set of Category objects (Assuming this is done in Service Layer)
        Set<Category> categories = new HashSet<>();
        movie.setCategories(categories);

        return movie;
    }
}
