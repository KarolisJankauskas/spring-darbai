package lt.techin.demo.dto.movie;

import lt.techin.demo.model.Category;
import lt.techin.demo.model.Review;

import java.time.LocalDate;
import java.util.List;

public record UpdateMovieResponseDTO(
        long id,
        String title,
        String director,
        String description,
        String imageUrl,
        int duration,
        LocalDate releaseDate,
        List<Review> reviews,
        List<Category> categories
) { }