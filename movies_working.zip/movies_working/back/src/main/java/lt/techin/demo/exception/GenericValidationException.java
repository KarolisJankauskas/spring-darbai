package lt.techin.demo.exception;

public class GenericValidationException extends RuntimeException {

    public GenericValidationException(String message) {
        super(message);
    }
}
