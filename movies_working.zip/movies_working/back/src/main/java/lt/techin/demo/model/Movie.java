package lt.techin.demo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Objects;

@Entity
@Table(name = "movies")
public class Movie {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long id;

  private String title;
  private String director;
  private String description;
  private String imageUrl;
  private int duration;
  private LocalDate releaseDate;

  @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  @JoinColumn(name = "movie_id")
  private List<Review> reviews;

  @ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE}, fetch = FetchType.LAZY)
  @JoinTable(
          name = "movie_categories",
          joinColumns = @JoinColumn(name = "movie_id"),
          inverseJoinColumns = @JoinColumn(name = "category_id")
  )
  private Set<Category> categories = new HashSet<>();

  public Movie() {
  }

  public Movie(String title, String director, String description, String imageUrl, int duration, LocalDate releaseDate) {
    this.title = title;
    this.director = director;
    this.description = description;
    this.imageUrl = imageUrl;
    this.duration = duration;
    this.releaseDate = releaseDate;
  }


  public Movie(long id, @NotEmpty @Size(min = 2, max = 150, message = "Maximum 150 characters and at least 2") String title, @NotEmpty @Size(max = 150, message = "Maximum 150 characters") @Pattern(regexp = "^[A-Z][a-z]+$", message = "Must start with an uppercase letter and continue as lowercase") String director, @NotEmpty @Size(max = 65_535) String description, @Size(max = 150) String s, @Min(value = 1, message = "Duration must be at least 1 minute") int duration, @PastOrPresent LocalDate localDate, List<Review> reviews, @NotEmpty(message = "Movie must have at least one genre") List<Category> categories) {
  }

  public <E> Movie(@NotEmpty @Size(min = 2, max = 150, message = "Maximum 150 characters and at least 2") String title, @NotEmpty @Size(max = 150, message = "Maximum 150 characters") @Pattern(regexp = "^[A-Z][a-z]+$", message = "Must start with an uppercase letter and continue as lowercase") String director, @NotEmpty @Size(max = 65_535) String description, @Size(max = 150) String s, int duration, @PastOrPresent LocalDate localDate, List<E> of, @NotEmpty(message = "Movie must have at least one genre") List<Category> categories) {

  }


  public long getId() {
    return id;
  }


  public void setId(long id) {
    this.id = id;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getDirector() {
    return director;
  }

  public void setDirector(String director) {
    this.director = director;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getImageUrl() {
    return imageUrl;
  }

  public void setImageUrl(String imageUrl) {
    this.imageUrl = imageUrl;
  }

  public int getDuration() {
    return duration;
  }

  public void setDuration(int duration) {
    this.duration = duration;
  }

  public LocalDate getReleaseDate() {
    return releaseDate;
  }

  public void setReleaseDate(LocalDate releaseDate) {
    this.releaseDate = releaseDate;
  }

  public List<Review> getReviews() {
    return reviews;
  }

  public void setReviews(List<Review> reviews) {
    this.reviews = reviews;
  }

  public Set<Category> getCategories() {
    return categories;
  }

  public void setCategories(Set<Category> categories) {
    this.categories = categories;
  }

  public void addCategory(Category category) {
    this.categories.add(category);
    category.getMovies().add(this);
  }

  public void removeCategory(Category category) {
    this.categories.remove(category);
    category.getMovies().remove(this);
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    Movie movie = (Movie) o;
    return id == movie.id;
  }

  @Override
  public int hashCode() {
    return Objects.hash(id);
  }

  @Override
  public String toString() {
    return "Movie{" +
            "id=" + id +
            ", title='" + title + '\'' +
            ", director='" + director + '\'' +
            ", description='" + description + '\'' +
            ", imageUrl='" + imageUrl + '\'' +
            ", duration=" + duration +
            ", releaseDate=" + releaseDate +
            '}';
  }
}