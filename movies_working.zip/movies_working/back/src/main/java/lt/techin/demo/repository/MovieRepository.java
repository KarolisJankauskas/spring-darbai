package lt.techin.demo.repository;

import lt.techin.demo.model.Movie;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

// Tipas klasės, ir jos pirminis raktas <Movie, Long>
public interface MovieRepository extends JpaRepository<Movie, Long> {

  // Derived query
  List<Movie> findAllByTitleContaining(String title);

  // Šis metodas ras filmus, jei pavadinimas yra vienas prie vieno
  List<Movie> findAllByTitle(String title);

  // JPQL query; veikia taip pat, kaip @NativeQuery
  // Sintaksė remiasi būtent Java kodu
  @Query("select m from Movie m where m.director = ?1")
  List<Movie> findAllByDirector(String director);

  // Native query example (commented out)
  // @Query(value = "SELECT * FROM movies WHERE director = ?1", nativeQuery = true)
  // List<Movie> findAllByDirector(String director);
}