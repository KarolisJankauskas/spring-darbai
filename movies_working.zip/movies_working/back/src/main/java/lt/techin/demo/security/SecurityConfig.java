//package lt.techin.demo.security;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.http.HttpMethod;
//import org.springframework.security.config.Customizer;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//
//import org.springframework.security.web.SecurityFilterChain;
//
//
//@Configuration
//@EnableWebSecurity
//public class SecurityConfig {
//
//  @Bean
//  public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//
//    http
//          .cors(Customizer.withDefaults())
//          .csrf(AbstractHttpConfigurer::disable)
//          .httpBasic(Customizer.withDefaults())
//          .authorizeHttpRequests((authorize) -> authorize
//                  .requestMatchers(HttpMethod.POST, "/api/auth/register").permitAll()
//                  .requestMatchers(HttpMethod.DELETE, "/api/movies/**").hasRole("ADMIN")
//                  .anyRequest().authenticated()
//          );
//
//    return http.build();
//  }
//
//  @Bean
//  public PasswordEncoder passwordEncoder() {
//    return new BCryptPasswordEncoder();
//  }
//
//}

package lt.techin.demo.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

  @Bean
  public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
    http
            .cors(Customizer.withDefaults()) // Enable CORS with default settings
            .csrf(AbstractHttpConfigurer::disable) // Disable CSRF protection (useful for APIs)
            .httpBasic(Customizer.withDefaults()) // Enable HTTP Basic Authentication
            .authorizeHttpRequests((authorize) -> authorize
                    // Public endpoints (accessible to everyone)
                    .requestMatchers(HttpMethod.GET, "/api/movies/**").permitAll() // Allow viewing movies
                    .requestMatchers(HttpMethod.GET, "/api/movies").permitAll() // Allow listing movies
                    .requestMatchers(HttpMethod.POST, "/api/auth/register").permitAll() // Allow user registration
                    .requestMatchers(HttpMethod.POST, "/api/auth/login").permitAll() // Allow user login
                    .requestMatchers(HttpMethod.GET, "/api/categories").permitAll()

                    // Restricted endpoints (require authentication or specific roles)
                    .requestMatchers(HttpMethod.DELETE, "/api/movies/**").hasRole("ADMIN") // Only admins can delete movies
                    .requestMatchers(HttpMethod.POST, "/api/movies").hasAnyRole("ADMIN", "USER") // Only authenticated users can add movies
                    .requestMatchers(HttpMethod.PUT, "/api/movies/**").hasAnyRole("ADMIN", "USER")// Only authenticated users can update movies
                    .requestMatchers(HttpMethod.DELETE, "/api/categories/**").hasRole("ADMIN") // Only admins can delete movies
                    .requestMatchers(HttpMethod.POST, "/api/categories").hasAnyRole("ADMIN", "USER") // Only authenticated users can add movies
                    .requestMatchers(HttpMethod.PUT, "/api/categories/**").hasAnyRole("ADMIN", "USER") // Only authenticated users can update movies
                    .requestMatchers(HttpMethod.POST, "/api/admin/add-movie/**").hasRole("ADMIN") // Only admins can delete movies
                    .requestMatchers(HttpMethod.PUT, "/api/admin/add-movie/**").hasRole("ADMIN") // Only admins can delete movies
                    .requestMatchers(HttpMethod.DELETE, "/api/admin/add-movie/**").hasRole("ADMIN") // Only admins can delete movies

                    // All other requests require authentication
                    .anyRequest().authenticated()
            );

    return http.build();
  }

  @Bean
  public PasswordEncoder passwordEncoder() {
    return new BCryptPasswordEncoder(); // Use BCrypt for password encoding
  }
}