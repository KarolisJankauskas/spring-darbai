package lt.techin.demo.service;

import lt.techin.demo.model.Movie;
import lt.techin.demo.model.Category;
import lt.techin.demo.repository.MovieRepository;
import lt.techin.demo.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class MovieService {

  private final MovieRepository movieRepository;
  private final CategoryRepository categoryRepository;

  @Autowired
  public MovieService(MovieRepository movieRepository, CategoryRepository categoryRepository) {
    this.movieRepository = movieRepository;
    this.categoryRepository = categoryRepository;
  }

  public List<Movie> findAllMovies() {
    return movieRepository.findAll();
  }

  public boolean existsMovieById(long id) {
    return movieRepository.existsById(id);
  }

  public Optional<Movie> findMovieById(long id) {
    return movieRepository.findById(id);
  }

  public Movie saveMovie(Movie movie, Set<Long> categoryIds) {
    // Fetch categories by IDs
    Set<Category> categories = categoryRepository.findAllByIdIn(categoryIds);
    movie.setCategories(categories); // Set the categories for the movie
    return movieRepository.save(movie);
  }

  public void deleteMovieById(long id) {
    movieRepository.deleteById(id);
  }

  public List<Movie> findAllMoviesByTitleContaining(String title) {
    return movieRepository.findAllByTitleContaining(title);
  }

  public List<Movie> findAllMoviesByDirector(String director) {
    return movieRepository.findAllByDirector(director);
  }

  public Page<Movie> findAllMoviesPage(Pageable pageable) {
    return movieRepository.findAll(pageable);
  }
}