import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { MainLayout } from "./layouts/MainLayout.jsx";
import { MovieList } from "./pages/movies/MovieList.jsx";
import { AuthGuard } from "./components/AuthGuard.jsx";
import { Login } from "./pages/auth/Login.jsx";
import { Register } from "./pages/auth/Register.jsx";
import { AuthProvider } from "./context/AuthContext.jsx";
import { ViewMovie } from "./pages/movies/ViewMovie.jsx";
import { Home } from "./pages/Home.jsx";
import { About } from "./pages/About.jsx";
import { Contact } from "./pages/Contact.jsx";
import { Navbar } from "./pages/movies/NavBar.jsx";
import { AddMoviePage } from "./pages/movies/AddMovie.jsx";
// import { Footer } from "./pages/Footer.jsx";

const App = () => {
    return (
        <BrowserRouter>
            <AuthProvider>
                {/* Navbar is placed outside Routes to appear on all pages */}
                <Navbar />
                <Routes>
                    {/* Public Routes */}
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />

                    {/* Protected Routes (wrapped in AuthGuard and MainLayout) */}
                    <Route
                        path="/"
                        element={
                            <AuthGuard>
                                <MainLayout />
                            </AuthGuard>
                        }
                    >
                        <Route index element={<Navigate to="home" replace />} />
                        <Route path="home" element={<Home />} />
                        <Route path="movies" element={<MovieList />} />
                        <Route path="movies/view/:id" element={<ViewMovie />} />
                        <Route path="about" element={<About />} />
                        <Route path="contact" element={<Contact />} />
                        <Route
                    path="/admin/add-movie"
                    element={
                        <AuthGuard>
                            <AddMoviePage />
                        </AuthGuard>
                    }
                />
                       
                    </Route>

                    {/* Fallback Route for Unknown Paths */}
                    <Route path="*" element={<Navigate to="/home" replace />} />
                </Routes>
                {/* <Footer /> */}
            </AuthProvider>
        </BrowserRouter>
    );
};

export default App;