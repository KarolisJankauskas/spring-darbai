import { createContext, useContext, useState } from "react";
import { useNavigate } from "react-router";
import api, { setAuth, clearAuth } from "../utils/api.js";

const AuthContext = createContext({
    user: null,
    login: () => {},
    logout: () => {},
    register: () => {},
});

export const AuthProvider = ({ children }) => {
    const navigate = useNavigate();
    const [user, setUser] = useState(() => {
        const maybeUser = localStorage.getItem("user");
        return maybeUser ? JSON.parse(maybeUser) : null;
    });

    const login = async (username, password) => {
        try {
            // Set auth credentials for axios
            setAuth(username, password);

            // Get user roles from server
            const response = await api.get("/auth/me");
            const userData = response.data;

            // Combine credentials with roles from database
            const user = {
                username,
                email: userData.email, // Add email from response
                roles: userData.roles,
            };

            // Save user info to localStorage (excluding password)
            localStorage.setItem("user", JSON.stringify(user));
            setUser(user);
            navigate("/movies");
        } catch (error) {
            console.error("Login failed:", error);
            throw error; // Re-throw the error for the calling component to handle
        }
    };

    const register = async (username, email, password) => {
        try {
            await api.post("/auth/register", {
                username,
                email,
                password,
            });
            navigate("/login");
        } catch (error) {
            console.error("Registration failed:", error);
            throw error; // Re-throw the error for the calling component to handle
        }
    };

    const logout = () => {
        setUser(null); // Clear user state
        clearAuth(); // Clear auth credentials from axios
        localStorage.removeItem("user"); // Remove user from localStorage
        navigate("/login"); // Redirect to login page
    };

    return (
        <AuthContext.Provider value={{ user, login, logout, register }}>
            {children}
        </AuthContext.Provider>
    );
};

// Custom hook to use AuthContext
export const useAuth = () => {
    return useContext(AuthContext);
};