export const About = () => {
    return (
        <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
            <h1 className="text-4xl font-bold text-gray-800 mb-4">About Us</h1>
            <p className="text-gray-600 text-lg text-center max-w-2xl mb-8">
                MovieApp is a platform designed for movie enthusiasts to explore,
                discover, and learn about their favorite films. Our mission is to
                provide a seamless experience for users to access detailed
                information about movies, including directors, release dates, and
                more. We are passionate about movies and aim to create a community
                where everyone can share their love for cinema.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-white p-6 rounded-lg shadow-md">
                    <h2 className="text-2xl font-bold text-gray-800 mb-4">Our Mission</h2>
                    <p className="text-gray-600">
                        To provide a comprehensive and user-friendly platform for
                        movie lovers to explore and enjoy their favorite films.
                    </p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-md">
                    <h2 className="text-2xl font-bold text-gray-800 mb-4">Our Vision</h2>
                    <p className="text-gray-600">
                        To become the go-to destination for movie enthusiasts
                        worldwide, offering the best experience in discovering and
                        learning about movies.
                    </p>
                </div>
            </div>
        </div>
    );
};