import { useState, useEffect } from "react";
import api from "../../utils/api.js";
import { useAuth } from "../../context/AuthContext.jsx";
import { useNavigate } from "react-router-dom";

export const AddMovieForm = () => {
    const { user } = useAuth();
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        title: "",
        director: "",
        releaseDate: "",
        duration: "",
        imageUrl: "",
        description: "",
        categoryIds: [], // Array of category IDs
    });
    const [categories, setCategories] = useState([]); // List of available categories
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");

    // Fetch available categories on component mount
    useEffect(() => {
        const fetchCategories = async () => {
            try {
                const response = await api.get("/categories");
                setCategories(response.data);
            } catch (error) {
                setError("Failed to fetch categories.");
            }
        };

        fetchCategories();
    }, []);

    // Handle input changes for text fields
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    // Handle category selection changes
    const handleCategoryChange = (e) => {
        const { value, checked } = e.target;
        const categoryId = parseInt(value, 10);

        if (checked) {
            setFormData((prev) => ({
                ...prev,
                categoryIds: [...prev.categoryIds, categoryId], // Add category ID to the array
            }));
        } else {
            setFormData((prev) => ({
                ...prev,
                categoryIds: prev.categoryIds.filter((id) => id !== categoryId), // Remove category ID from the array
            }));
        }
    };

    // Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");
        setSuccess("");

        // Check if the user is logged in
        if (!user) {
            setError("You must be logged in to add movies.");
            return;
        }

        // Check if the user is an admin
        if (!user?.roles?.includes("ROLE_ADMIN")) {
            setError("You do not have permission to add movies.");
            return;
        }

        // Validate form data
        if (
            !formData.title ||
            !formData.director ||
            !formData.releaseDate ||
            !formData.duration ||
            !formData.imageUrl ||
            !formData.description ||
            formData.categoryIds.length === 0
        ) {
            setError("All fields are required, and at least one genre must be selected.");
            return;
        }

        // Format the payload to match the backend's expectations
        const formattedData = {
            title: formData.title,
            director: formData.director,
            releaseDate: new Date(formData.releaseDate).toISOString().split("T")[0], // Format as YYYY-MM-DD
            duration: parseInt(formData.duration, 10), // Ensure duration is a number
            imageUrl: formData.imageUrl,
            description: formData.description,
            categories: formData.categoryIds.map((id) => ({ id })), // Convert category IDs to Category objects
        };

        // Log the formatted data for debugging
        console.log("Formatted Data:", formattedData);

        try {
            const response = await api.post("/movies", formattedData);
            console.log("API Response:", response.data); // Log the API response
            setSuccess("Movie added successfully!");

            // Clear the form after successful submission
            setFormData({
                title: "",
                director: "",
                releaseDate: "",
                duration: "",
                imageUrl: "",
                description: "",
                categoryIds: [],
            });

            // Redirect to the movie list after a short delay
            setTimeout(() => {
                navigate("/movies"); // Redirect to the movie list
            }, 2000); // 2-second delay
        } catch (error) {
            console.error("API Error:", error.response?.data || error.message); // Log the full error
            setError(error.response?.data?.message || error.message || "Failed to add movie.");
        }
    };

    return (
        <div className="max-w-md mx-auto p-6 bg-white shadow-md rounded-lg">
            <h2 className="text-2xl font-bold mb-4 text-gray-800">Add a New Movie</h2>
            {error && <div className="text-red-500 mb-4">{error}</div>}
            {success && <div className="text-green-500 mb-4">{success}</div>}
            <form onSubmit={handleSubmit} className="space-y-4">
                {/* Title */}
                <div>
                    <label className="block text-gray-700">Title</label>
                    <input
                        type="text"
                        name="title"
                        value={formData.title}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                        minLength={2}
                        maxLength={150}
                    />
                </div>

                {/* Director */}
                <div>
                    <label className="block text-gray-700">Director</label>
                    <input
                        type="text"
                        name="director"
                        value={formData.director}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                        maxLength={150}
                        pattern="^[A-Z][a-z]+( [A-Z][a-z]+)*$" // Matches names like "James Cameron"
                    />
                </div>

                {/* Release Date */}
                <div>
                    <label className="block text-gray-700">Release Date</label>
                    <input
                        type="date"
                        name="releaseDate"
                        value={formData.releaseDate}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                        max={new Date().toISOString().split("T")[0]} // Ensure date is in the past or present
                    />
                </div>

                {/* Duration */}
                <div>
                    <label className="block text-gray-700">Duration (minutes)</label>
                    <input
                        type="number"
                        name="duration"
                        value={formData.duration}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                        min={1} // Ensure duration is at least 1 minute
                    />
                </div>

                {/* Image URL */}
                <div>
                    <label className="block text-gray-700">Image URL</label>
                    <input
                        type="url"
                        name="imageUrl"
                        value={formData.imageUrl}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                        maxLength={150}
                    />
                </div>

                {/* Description */}
                <div>
                    <label className="block text-gray-700">Description</label>
                    <textarea
                        name="description"
                        value={formData.description}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                        maxLength={65535}
                    />
                </div>

                {/* Categories */}
                <div>
                    <label className="block text-gray-700">Categories</label>
                    <div className="space-y-2">
                        {categories.map((category) => (
                            <label key={category.id} className="flex items-center space-x-2">
                                <input
                                    type="checkbox"
                                    name="categories"
                                    value={category.id}
                                    checked={formData.categoryIds.includes(category.id)}
                                    onChange={handleCategoryChange}
                                    className="form-checkbox h-5 w-5 text-blue-600"
                                />
                                <span>{category.name}</span>
                            </label>
                        ))}
                    </div>
                </div>

                {/* Submit Button */}
                <button
                    type="submit"
                    className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors duration-300"
                >
                    Add Movie
                </button>
            </form>
        </div>
    );
};