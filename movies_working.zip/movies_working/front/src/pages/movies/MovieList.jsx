import { useEffect, useState, useCallback } from "react";
import api from "../../utils/api.js";
import { MovieCard } from "../../components/MovieCard.jsx";
import { Error } from "../../components/Error.jsx";

export const MovieList = () => {
    const [movies, setMovies] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [pageSize, setPageSize] = useState(12);
    const [totalPages, setTotalPages] = useState(12);
    const [error, setError] = useState("");
    const [isLoading, setIsLoading] = useState(false);

    // Fetch movies for the current page and size
    const getMoviePage = useCallback(async () => {
        setError(""); // Clear previous errors
        setIsLoading(true); // Set loading state
        try {
            const response = await api.get(`/movies`); // Fetch all movies
            console.log("API Response:", response.data); // Log API response for debugging

            // Ensure the response is an array
            if (Array.isArray(response.data)) {
                setMovies(response.data); // Set movies data
                setTotalPages(Math.ceil(response.data.length / pageSize)); // Calculate total pages
            } else {
                setError("Invalid data format received from the server.");
                console.error("Invalid API response structure:", response.data);
            }
        } catch (error) {
            setError(error.response?.data?.message || error.message || "Failed to fetch movies.");
            console.error("API Error:", error);
        } finally {
            setIsLoading(false); // Reset loading state
        }
    }, [pageSize]);

    // Handle page size change
    const onPageSizeChange = async (e) => {
        const newPageSize = parseInt(e.target.value, 10);
        setPageSize(newPageSize);
        setCurrentPage(1); // Reset to the first page
    };

    // Handle pagination
    const onPaginate = (page) => {
        if (page < 1 || page > totalPages) return; // Validate page range
        setCurrentPage(page);
    };

    // Fetch movies on component mount or when pageSize changes
    useEffect(() => {
        getMoviePage();
    }, [getMoviePage]);

    // Calculate paginated movies
    const paginatedMovies = movies.slice(
        (currentPage - 1) * pageSize,
        currentPage * pageSize
    );

    return (
        <div className="flex flex-col items-center gap-8 p-8">
            {isLoading ? (
                <p className="text-gray-600">Loading movies...</p>
            ) : (
                <>
                    {/* Display movies */}
                    {paginatedMovies.length > 0 ? (
                        <ul className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                            {paginatedMovies.map((movie) => (
                                <MovieCard
                                    key={movie.id}
                                    movie={movie}
                                    getMoviePage={getMoviePage}
                                    currentPage={currentPage}
                                    pageSize={pageSize}
                                />
                            ))}
                        </ul>
                    ) : (
                        <p className="text-gray-600">No movies found.</p>
                    )}

                    {/* Pagination controls */}
                    <div className="join">
                        <button
                            className="join-item btn"
                            onClick={() => onPaginate(currentPage - 1)}
                            disabled={currentPage === 1 || isLoading}
                        >
                            «
                        </button>
                        <button className="join-item btn">Page {currentPage}</button>
                        <button
                            className="join-item btn"
                            onClick={() => onPaginate(currentPage + 1)}
                            disabled={currentPage === totalPages || isLoading}
                        >
                            »
                        </button>
                        <select
                            value={pageSize}
                            className="join-item select ml-4"
                            onChange={onPageSizeChange}
                            disabled={isLoading}
                        >
                            <option value="6">6</option>
                            <option value="12">12</option>
                            <option value="15">15</option>
                        </select>
                    </div>
                </>
            )}

            {/* Display error message if any */}
            {error && <Error error={error} />}
        </div>
    );
};