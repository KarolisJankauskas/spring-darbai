export const ViewMovie = () => {
    return (
        <div className="grid place-items-center h-100">
            <p>Not implemented :c</p>
        </div>
    );
};